"""ImageGenerationPort adapter backed by OpenAI gpt-image-1-mini.

Drop-in replacement for the old Replicate/Flux adapter. The rest of the
system (activities, dto, repository) still depends on ImageGenerationPort —
only this file changed.
"""
from __future__ import annotations

import base64
import io
from typing import Any

from PIL import Image

from app.assets.ports import GeneratedImage
from app.common.exceptions import InfrastructureError
from app.common.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# !! HARDCODE YOUR OPENAI API KEY HERE (optional) !!
# If set, this takes priority over anything in settings.
# Leave as None to fall back to the OPENAI_API_KEY environment variable.
# ---------------------------------------------------------------------------
HARDCODED_OPENAI_API_KEY: str | None = "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"
# Example:
# HARDCODED_OPENAI_API_KEY = "sk-..."

_DEFAULT_MODEL = "gpt-image-2.5-flare"
_DEFAULT_SIZE = "1024x1024"
_DEFAULT_QUALITY = "auto"


class ReplicateImageGenerationAdapter:
    """ImageGenerationPort implementation using OpenAI image generation.

    The class name is kept as-is so adapters/__init__.py doesn't need
    changing — only the implementation underneath was swapped from Replicate.

    ``idempotency_key`` is carried in structured logs for tracing.
    """

    def __init__(
        self,
        api_token: str | None = None,
        model: str | None = None,
    ) -> None:
        from openai import AsyncOpenAI  # imported here: adapters own the SDK

        resolved_key = HARDCODED_OPENAI_API_KEY or api_token
        if not resolved_key:
            raise InfrastructureError("OpenAI API key is not configured.")

        self._client = AsyncOpenAI(api_key=resolved_key)
        self._model = model or _DEFAULT_MODEL

    async def generate(self, prompt: str, idempotency_key: str, **params: Any) -> GeneratedImage:
        try:
            result = await self._client.images.generate(
                model=self._model,
                prompt=prompt,
                size=params.get("size", _DEFAULT_SIZE),
                quality=params.get("quality", _DEFAULT_QUALITY),
                output_format="png",
            )
        except Exception as exc:
            logger.error("openai_image_generation_failed", error=repr(exc))
            raise InfrastructureError(f"OpenAI image generation failed: {exc}") from exc

        b64_data = result.data[0].b64_json
        if not b64_data:
            raise InfrastructureError("OpenAI returned no image data.")

        data = base64.b64decode(b64_data)

        with Image.open(io.BytesIO(data)) as img:
            width, height = img.size

        logger.info(
            "openai_image_generated",
            idempotency_key=idempotency_key,
            model=self._model,
        )
        return GeneratedImage(
            data=data,
            width=width,
            height=height,
            provider_request_id=idempotency_key,
        )


# ==================================================================================
# !! OLD REPLICATE IMPLEMENTATION (commented out) !!
# ==================================================================================

# """Real ImageGenerationPort adapter backed by Replicate-hosted Flux."""
# from __future__ import annotations
#
# import io
# from typing import Any
#
# import httpx
# from PIL import Image
#
# from app.assets.ports import GeneratedImage
# from app.common.exceptions import InfrastructureError
# from app.common.logging import get_logger
# from app.config import get_settings
#
# logger = get_logger(__name__)
#
# _REPLICATE_API_BASE = "https://api.replicate.com/v1"
# _DEFAULT_FLUX_MODEL = "black-forest-labs/flux-schnell"
#
#
# class ReplicateImageGenerationAdapter:
#     def __init__(self, api_token: str | None = None, model: str | None = None) -> None:
#         settings = get_settings()
#         self._api_token = api_token or getattr(settings, "replicate_api_token", None)
#         self._model = model or getattr(settings, "replicate_flux_model", None) or _DEFAULT_FLUX_MODEL
#         if not self._api_token:
#             raise InfrastructureError("Replicate API token is not configured.")
#
#     async def generate(self, prompt: str, idempotency_key: str, **params: Any) -> GeneratedImage:
#         async def _create_prediction() -> dict[str, Any]:
#             async with httpx.AsyncClient(timeout=120) as client:
#                 response = await client.post(
#                     f"{_REPLICATE_API_BASE}/models/{self._model}/predictions",
#                     headers={
#                         "Authorization": f"Bearer {self._api_token}",
#                         "Content-Type": "application/json",
#                         "Prefer": "wait",
#                     },
#                     json={"input": {"prompt": prompt, **params}},
#                 )
#                 response.raise_for_status()
#                 return response.json()
#
#         payload = await _create_prediction()
#         output = payload.get("output")
#         image_url = output[0] if isinstance(output, list) and output else output
#         if not image_url:
#             raise InfrastructureError(f"Replicate returned no image output: {payload!r}")
#
#         async def _download_image() -> bytes:
#             async with httpx.AsyncClient(timeout=120) as client:
#                 image_response = await client.get(image_url)
#                 image_response.raise_for_status()
#                 return image_response.content
#
#         data = await _download_image()
#         with Image.open(io.BytesIO(data)) as img:
#             width, height = img.size
#
#         logger.info("replicate_image_generated", idempotency_key=idempotency_key, prediction_id=payload.get("id"))
#         return GeneratedImage(data=data, width=width, height=height, provider_request_id=payload.get("id"))